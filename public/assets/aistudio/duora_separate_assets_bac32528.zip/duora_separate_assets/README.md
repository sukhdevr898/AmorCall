# Duora UI Asset Pack (cropped from the provided visual reference)

Folders:
- logos/: light and dark Duora logo crops
- app_icons/: launcher icon crops
- backgrounds/: five background/wallpaper crops
- light_mode/ and dark_mode/: navigation, feature, call, chat, and top-bar icon crops
- status/: status indicators and message ticks reference crop
- ui_components/: buttons, message input, toggles, chat bubbles, call cards
- avatars/: avatar placeholder strip

Notes:
- This pack contains individually cropped PNG assets from the provided design sheet. Some icon crops retain their original tile/card background to preserve the reference appearance.
- They are visual crops, not vector redraws; use SVG/vector icons for production scaling if you need crisp resizable glyphs.
- Asset names are descriptive and organized for easy copying into your app assets.
